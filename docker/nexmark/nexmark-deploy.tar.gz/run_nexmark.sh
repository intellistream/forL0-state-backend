#!/usr/bin/env bash
################################################################################
#  在 Docker 集群环境下运行 NexMark SQL Benchmark
#
#  前置条件:
#    1. ForL0 JAR 已复制到 $FLINK_HOME/lib/
#    2. Docker Flink 集群正在运行 (./docker_run.sh start)
#    3. nexmark-flink 已解压到本脚本同级目录
#
#  用法:
#    ./run_nexmark.sh                    # 运行所有 query (100M events)
#    ./run_nexmark.sh q5                 # 运行单个 query
#    ./run_nexmark.sh q5,q7,q8           # 运行多个 query
#    ./run_nexmark.sh all                # 运行所有 query
#
#  切换后端:
#    BACKEND=hashmap ./run_nexmark.sh q5  # 使用 HashMap 后端
#    BACKEND=forl0  ./run_nexmark.sh q5   # 使用 ForL0 后端 (默认)
################################################################################

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
NEXMARK_HOME="${SCRIPT_DIR}/nexmark-flink"
FLINK_HOME="${FLINK_HOME:-/home/user/flink}"
BACKEND="${BACKEND:-forl0}"
QUERY="${1:-all}"
REST_URL="http://localhost:8081"

# ========== 检查 ==========

if [[ ! -d "$NEXMARK_HOME" ]]; then
    echo "✗ nexmark-flink 目录不存在: ${NEXMARK_HOME}"
    echo "  请先解压: cd $(dirname $0) && tar xzf nexmark-flink.tgz"
    exit 1
fi

if [[ ! -d "$FLINK_HOME/lib" ]]; then
    echo "✗ FLINK_HOME 无效: ${FLINK_HOME}"
    echo "  请设置: export FLINK_HOME=/path/to/flink"
    exit 1
fi

# 检查 ForL0 JAR
FORL0_JAR=$(find "$FLINK_HOME/lib" -name "flink-statebackend-forL0-*.jar" 2>/dev/null | head -1)
if [[ "$BACKEND" == "forl0" && -z "$FORL0_JAR" ]]; then
    echo "✗ ForL0 JAR 未找到于 $FLINK_HOME/lib/"
    echo "  请先复制: cp flink-statebackend-forL0-*.jar $FLINK_HOME/lib/"
    exit 1
fi

# 检查集群是否可达
if ! curl -sf "${REST_URL}/overview" >/dev/null 2>&1; then
    echo "✗ Flink 集群不可达 (${REST_URL})"
    echo "  请确认 Docker 集群已启动: cd ../docker && ./docker_run.sh start"
    exit 1
fi

# ========== 准备 Flink 配置 ==========
# sql-client.sh 使用 $FLINK_CONF_DIR 的配置连接集群
# 创建一个临时的 Flink 配置，指向 localhost:8081 并设置 state backend

CONF_DIR="${SCRIPT_DIR}/flink-conf-${BACKEND}"
mkdir -p "$CONF_DIR"

if [[ "$BACKEND" == "forl0" ]]; then
    cat > "$CONF_DIR/config.yaml" << 'CONF'
# Auto-generated Flink config for NexMark benchmark (ForL0 backend)
rest.address: localhost
rest.port: 8081
jobmanager.rpc.address: localhost
parallelism.default: 8

# ForL0 State Backend
state.backend.type: org.apache.flink.state.forl0.ForL0StateBackendFactory
state.backend.forl0.l0-cache.enabled: true
state.backend.forl0.l0-cache.size: 24mb
state.backend.forl0.l0-cache.max-per-alloc: 128kb

# Table 优化
table.exec.mini-batch.enabled: true
table.exec.mini-batch.allow-latency: 2s
table.exec.mini-batch.size: 50000
table.optimizer.distinct-agg.split.enabled: true

# Checkpoint (关闭以获得纯吞吐量数据)
execution.checkpointing.checkpoints-after-tasks-finish.enabled: false
CONF
elif [[ "$BACKEND" == "hashmap" ]]; then
    cat > "$CONF_DIR/config.yaml" << 'CONF'
# Auto-generated Flink config for NexMark benchmark (HashMap backend)
rest.address: localhost
rest.port: 8081
jobmanager.rpc.address: localhost
parallelism.default: 8

# HashMap State Backend
state.backend.type: hashmap

# Table 优化
table.exec.mini-batch.enabled: true
table.exec.mini-batch.allow-latency: 2s
table.exec.mini-batch.size: 50000
table.optimizer.distinct-agg.split.enabled: true

# Checkpoint (关闭以获得纯吞吐量数据)
execution.checkpointing.checkpoints-after-tasks-finish.enabled: false
CONF
else
    echo "✗ 未知后端: $BACKEND (支持: forl0, hashmap)"
    exit 1
fi

# ========== 运行 ==========

echo "============================================================"
echo " NexMark SQL Benchmark"
echo "============================================================"
echo "  FLINK_HOME:  ${FLINK_HOME}"
echo "  NEXMARK_HOME: ${NEXMARK_HOME}"
echo "  Backend:     ${BACKEND}"
echo "  Queries:     ${QUERY}"
echo "  REST URL:    ${REST_URL}"
echo "============================================================"

# 集群概览
OVERVIEW=$(curl -sf "${REST_URL}/overview" 2>/dev/null || echo '{}')
TM_COUNT=$(echo "$OVERVIEW" | python3 -c "import sys,json; print(json.load(sys.stdin).get('taskmanagers',0))" 2>/dev/null || echo "?")
SLOTS=$(echo "$OVERVIEW" | python3 -c "import sys,json; print(json.load(sys.stdin).get('slots-total',0))" 2>/dev/null || echo "?")
echo "  TaskManagers: ${TM_COUNT}, Slots: ${SLOTS}"
echo ""

# 设置环境变量
export FLINK_HOME
export FLINK_CONF_DIR="$CONF_DIR"

# 运行 nexmark
cd "$NEXMARK_HOME"
exec bin/run_query.sh "$QUERY"
