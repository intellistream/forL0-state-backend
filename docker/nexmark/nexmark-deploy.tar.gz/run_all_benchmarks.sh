#!/usr/bin/env bash
################################################################################
#  NexMark 全量对比测试: ForL0 vs HashMap
#
#  运行重点 Query 的 ForL0 和 HashMap 对比测试，输出对比表格
#
#  用法:
#    ./run_all_benchmarks.sh              # 运行带状态的关键 query
#    ./run_all_benchmarks.sh q5           # 只运行 q5 对比
#    QUERIES="q5,q7,q8" ./run_all_benchmarks.sh  # 自定义 query 列表
################################################################################

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
FLINK_HOME="${FLINK_HOME:-/home/user/flink}"
REST_URL="http://localhost:8081"

# 关键有状态 Query:
#   q5  - Hot Items (sliding window + join)
#   q7  - Highest Bid (tumbling window + join)
#   q8  - Monitor New Users (tumbling window + join)
#   q11 - User Sessions (session window)
#   q12 - Processing Time Windows
#   q3  - Local Item Suggestion (join + filter)
#   q4  - Average Price for a Category (join + tumbling window)
DEFAULT_QUERIES="q5,q7,q8,q11,q12"

if [[ $# -gt 0 ]]; then
    QUERIES="$1"
else
    QUERIES="${QUERIES:-${DEFAULT_QUERIES}}"
fi

TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
RESULTS_DIR="${SCRIPT_DIR}/results_${TIMESTAMP}"
mkdir -p "$RESULTS_DIR"

echo "============================================================"
echo " NexMark 全量对比测试: ForL0 vs HashMap"
echo "============================================================"
echo "  Queries: ${QUERIES}"
echo "  结果目录: ${RESULTS_DIR}"
echo ""

# 分割 query 列表
IFS=',' read -ra QUERY_ARRAY <<< "$QUERIES"

# ========== 运行 HashMap 后端 ==========
echo ""
echo "==============================="
echo " Phase 1: HashMap Backend"
echo "==============================="

for q in "${QUERY_ARRAY[@]}"; do
    echo ""
    echo "--- Running ${q} with hashmap ---"
    
    # 取消所有运行中的 job
    curl -sf "${REST_URL}/jobs" 2>/dev/null | python3 -c "
import sys,json
data = json.load(sys.stdin)
for j in data.get('jobs',[]):
    if j['status'] == 'RUNNING':
        import urllib.request
        req = urllib.request.Request('${REST_URL}/jobs/'+j['id'], method='PATCH')
        urllib.request.urlopen(req)
" 2>/dev/null || true
    sleep 2
    
    BACKEND=hashmap "${SCRIPT_DIR}/run_nexmark.sh" "$q" 2>&1 | tee "${RESULTS_DIR}/hashmap_${q}.log" || true
    
    echo "--- ${q} hashmap 完成 ---"
    sleep 5
done

# ========== 运行 ForL0 后端 ==========
echo ""
echo "==============================="
echo " Phase 2: ForL0 Backend"
echo "==============================="

for q in "${QUERY_ARRAY[@]}"; do
    echo ""
    echo "--- Running ${q} with forl0 ---"
    
    # 取消所有运行中的 job
    curl -sf "${REST_URL}/jobs" 2>/dev/null | python3 -c "
import sys,json
data = json.load(sys.stdin)
for j in data.get('jobs',[]):
    if j['status'] == 'RUNNING':
        import urllib.request
        req = urllib.request.Request('${REST_URL}/jobs/'+j['id'], method='PATCH')
        urllib.request.urlopen(req)
" 2>/dev/null || true
    sleep 2
    
    BACKEND=forl0 "${SCRIPT_DIR}/run_nexmark.sh" "$q" 2>&1 | tee "${RESULTS_DIR}/forl0_${q}.log" || true
    
    echo "--- ${q} forl0 完成 ---"
    sleep 5
done

# ========== 打印结果 ==========
echo ""
echo "============================================================"
echo " 测试完成"
echo "============================================================"
echo " 结果保存于: ${RESULTS_DIR}"
echo ""
echo " 查看 HashMap 结果: cat ${RESULTS_DIR}/hashmap_*.log"
echo " 查看 ForL0 结果:   cat ${RESULTS_DIR}/forl0_*.log"
echo "============================================================"
