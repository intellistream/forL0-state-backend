# Benchmark set：Heap / BriskState 无L0 / BriskState L0

**模式：DRAM_VALIDATION_ONLY**

配置：JM4核8GiB；两个TM各4核32GiB；p8；均匀分布；feature width64/touches128；CP关闭。

吞吐单位为 input-equivalent records/s，按终端Sink窗口计数除以拓扑输出倍数；初始化不计入吞吐。

| Workload | Heap | BriskState 无L0 | BriskState L0 | L0/无L0 |
|---|---:|---:|---:|---:|
| WC | 394,433.20 | 780,308.60 | — | — |

所有成功和失败运行均保留；不根据加速比筛除数据。原始逐轮数据见 results.csv/results.json，日志和配置见 raw/。

CPU限制为整个进程及其Java/GC/JIT/native线程的affinity；32GiB为Flink process预算，非OS硬RSS上限。

**此结果仅为普通内存下的离线流程验收，开启列实际使用DRAM驻留池，不能作为真实L0加速结果。**
