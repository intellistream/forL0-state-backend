# Benchmark set：Heap / BriskState 无L0 / 三档L0

**模式：DRAM_VALIDATION_ONLY**

配置：JM4核8GiB；两个TM各4核32GiB；p8；均匀分布；feature width64/touches128；CP关闭。

吞吐单位为 input-equivalent records/s，按终端Sink窗口计数除以拓扑输出倍数；初始化不计入吞吐。

三档共享L0容量为 17.5, 35, 52.5 MiB；每TM分配一半，按启动时双进程完整读写探测确定。

| Workload | Heap | BriskState 无L0 | L0 17.5 MiB | L0 35 MiB | L0 52.5 MiB |
|---|---:|---:|---:|---:|---:|
| WC | — | — | — | — | — |
| FD | — | — | — | — | — |
| SD | — | — | — | — | — |
| TM | — | — | — | — | — |
| LG | — | — | — | — | — |
| VS | — | 38,227.26 | 38,117.30 | 41,453.86 | 44,550.44 |
| LR | — | — | — | — | — |

| Workload | L0 25% / 无L0 | L0 50% / 无L0 | L0 75% / 无L0 |
|---|---:|---:|---:|
| WC | — | — | — |
| FD | — | — | — |
| SD | — | — | — |
| TM | — | — | — |
| LG | — | — | — |
| VS | 0.9971× (-0.29%) | 1.0844× (+8.44%) | 1.1654× (+16.54%) |
| LR | — | — | — |

所有成功和失败运行均保留；不根据加速比筛除数据。原始逐轮数据见 results.csv/results.json，日志和配置见 raw/。

CPU限制为整个进程及其Java/GC/JIT/native线程的affinity；32GiB为Flink process预算，非OS硬RSS上限。

**此结果仅为普通内存下的离线流程验收，开启列实际使用DRAM驻留池，不能作为真实L0加速结果。**
